# Kulturverein Blankenfelde e.V. — Website

Statische Website (HTML/CSS) für den Kulturverein Blankenfelde e.V.,
basierend auf dem Content der bisherigen Jimdo-Seite (kulturverein-blankenfelde.de).

## Struktur

```
index.html          Startseite mit allen Bereichen (Programm, Über uns, Impressionen, Publikationen, Kontakt)
css/style.css        Styles (Design-Token-System: Tafelgrün/Papier/Ocker/Ziegelrot)
fonts/                Selbst gehostete Schriften (Fraunces, Karla) — keine Google-Fonts-Requests
```

## Lokal ansehen

Einfach `index.html` im Browser öffnen, oder z. B. mit einem einfachen Server:

```bash
python3 -m http.server 8000
```

und dann `http://localhost:8000` aufrufen.

## Offene Punkte vor Veröffentlichung

- **E-Mail-Adresse** im Kontakt-Bereich ergänzen (auf der alten Seite Cloudflare-verschlüsselt, konnte nicht automatisch ausgelesen werden)
- **Aulaparkfest (27. Juni):** Widerspruch auf der alten Seite prüfen — im Kalender gelistet, an anderer Stelle als „ausgefallen" vermerkt
- Fotos für „LEIGA, Galerie" und „Heimatgeschichte" in der Impressionen-Sektion ergänzen (aktuell Platzhalter)
- Rechtstexte (Impressum, Datenschutz) von der alten Seite migrieren — Footer-Links sind aktuell Platzhalter
- Programm ab September 2026 ergänzen, sobald verfügbar

## Lizenz der Schriften

Fraunces und Karla stehen unter der SIL Open Font License und dürfen frei
weitergegeben und im Projekt eingebettet werden.
